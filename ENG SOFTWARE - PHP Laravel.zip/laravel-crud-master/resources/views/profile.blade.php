@extends('layouts.master')

@section('content')

    <h3>Welcome, {{$user->name}}</h3>

@endsection