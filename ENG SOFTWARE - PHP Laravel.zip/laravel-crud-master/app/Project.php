<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $fillable = [
    	'name',
    	'data_nasc',
    	'tel',
    	'email',
    ];
}
