<?php

// Pegar os campos do formulario
$nome = $_POST["registrar_nome"];
$email = $_POST["registrar_email"];
$endereco = $_POST["registrar_endereco"];
$telefone = $_POST["registrar_telefone"];
$cpf = $_POST["registrar_cpf"];
$username = $_POST["registrar_username"];
$senha = $_POST["registrar_senha"];
$senhaagain = $_POST["registrar_senha2"];

if( $senha!=$senhaagain){
    header("Location:registrar_cliente.php?erro=Senhas diferentes");
}


// Montar o SQL para pesquisar
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql1 = "INSERT into cliente (nome, email, endereco, telefone, cpf, username) values (" . "'" . $nome . "','" .  $email . "','" . $endereco . "','" .  $telefone . "','" .  $cpf . "','" .  $username . "'" . ")";
$res1 = mysqli_query($db, $sql1);

$sql2 = "INSERT into login (username, password, tipo) values (" . "'" . $username . "','" . $senha . "','" . 1 . "'" . ")";
$res = mysqli_query($db, $sql2);

header("Location:index.php?sucesso=Cadastrado com sucesso");
?>