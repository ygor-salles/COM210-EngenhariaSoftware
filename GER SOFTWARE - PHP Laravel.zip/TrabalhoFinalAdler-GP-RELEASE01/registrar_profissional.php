<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport"
          content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
    <link rel="stylesheet" href="www/libs/onsen/css/onsenui.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/onsenui-core.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/onsen-css-components.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/ionicons/css/ionicons.min.css">
    <script type="text/javascript" src="www/libs/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="www/libs/mask/jquery.mask.js"></script>
    <script type="text/javascript" src="www/libs/onsen/js/onsenui.min.js"></script>
    <link rel="stylesheet" href="www/libs/onsen/css/theme.css">
    <link rel="stylesheet" href="www/assets/css/custom.css">
    <link rel="stylesheet" href="www/assets/css/profissional.css">
    <link rel="stylesheet" href="www/assets/css/cliente.css">

    <script type="text/javascript" src="www/assets/scripts/platformOverrides.js"></script>
    <script type="text/javascript" src="www/assets/scripts/funcoes.js"></script>
    <script type="text/javascript" src="www/assets/scripts/custom.js"></script>
    <script src="www/assets/scripts/autenticacao.js"></script>
    <title>Sistema de Contratação de Transportadores Autônomos</title>

</head>
<body>
<ons-page id="registrar">
    <div class="container_cli">
        <div class="left">
            <a href="registrar.php"><ons-back-button ></ons-back-button></a>
        </div>
        <div class="centralizar">
            <img width="113px" height="97px" src="www/assets/images/estabelecimento.png">
        </div>
        <p class="centralizar" style="padding: 30px;">
            Preencha todos os campos abaixos
        </p>

        <form action="cadastrar_profissional.php" method="post" name="Cadastroprofissional">
            <div class="form-group">
                <p>
                    <input name="registrar_nome" class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Nome">
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_email"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="email" placeholder="Email" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_endereco"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Endereço" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_telefone"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Telefone" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_cpf"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="CPF" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_username"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Nome de usuário" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_cnpj"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="CNPJ" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_especializacao"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Especialização" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_servicos"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Serviços" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_senha"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="password" placeholder="Senha" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input name="registrar_senha2"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="password" placeholder="Repetir senha" >
                </p>
            </div>

            <div class="form-group">
                <div class="form-input" style="margin-top:50px;">
                    <button type="submit" class="button-default login-button-default"
                            modifier="medium">Continuar
                    </button>
                </div>
            </div>
        </form>
    </div>
</ons-page>

</body>
</html>