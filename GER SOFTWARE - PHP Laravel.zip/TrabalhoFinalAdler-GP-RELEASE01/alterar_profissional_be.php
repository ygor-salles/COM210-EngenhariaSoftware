
<?php
include_once("validar.php");
?>
<?php
// Pegar os campos do formulario
$nome = $_POST["registrar_nome"];
$email = $_POST["registrar_email"];
$endereco = $_POST["registrar_endereco"];
$telefone = $_POST["registrar_telefone"];
$senha = $_POST["registrar_senha"];
$senhaagain = $_POST["registrar_senha2"];
$servicos = $_POST["registrar_servicos"];
$especializacao = $_POST["registrar_especializacao"];

$login=$_SESSION["login"];

if( $senha!=$senhaagain){
    header("Location:alterar_profissional.php?erro=Senhas diferentes");
}


// Montar o SQL para pesquisar
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql1 = "UPDATE profissional SET
          nome ='" . $nome . "',
          email ='" . $email . "',
          endereco ='" . $endereco . "',
          telefone ='" . $telefone . "' ,
          especializacao ='" . $especializacao . "',
          servicos ='" . $servicos . "'
          where username= '" . $login . "'";
$res1 = mysqli_query($db, $sql1);

$sql2 = "UPDATE login SET
          password ='" . $senha . "'
          where username= '" . $login . "'";
$res = mysqli_query($db, $sql2);
header("Location:home_profissional.php?sucesso=Alterações realizadas com sucesso.");
?>