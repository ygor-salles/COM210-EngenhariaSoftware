<?php include "view/header.php";
$login = $_SESSION["login"];
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql = "SELECT * from profissional";
$result = $db->query($sql);
while ($row = $result->fetch_assoc()){
?>
    <ons-page id="profissionais">
        <div class="container_cli">
            <div class="left">
                <a href="menu_cliente.php"><ons-back-button ></ons-back-button></a>
            </div>
            <p style="text-align: center; margin-top: 10px;">
                <ons-search-input
                        placeholder="Procurar"
                        onchange="ons.notification.alert('(não implementado)Pesquisado por: ' + this.value)"></ons-search-input>
            </p>

            <form method="post" action="registra_requisicao.php">
                <?php
                    foreach($result as $profissional){
                ?>
                <div class="profissional card" style="height: auto!important; box-shadow: 0 1px 2px rgba(0,0,0,.42)!important;width: 282px!important; margin-left:46.5px!important;">
                    <div class="profile-img profissional_img">
                        <img class="profile-image" width="50px" height="50px" src="www/assets/images/profile-generic.jpg"  style="margin-top:16.5px; border-radius:50%;">
                    </div>
                    <div class="profissional_txt">
                        <p style="text-align:left;">
                            <?php echo $profissional['nome'];?><br>
                            <?php echo $profissional['endereco'];?><br>
                            <?php echo $profissional['telefone'];?><br>
                            <?php echo $profissional['especializacao'];?><br>
                            <?php echo $profissional['servicos'];?>
                        </p>
                    </div>
                </div>
                <?php
                    }
                ?>
            </form>
        </div>
    </ons-page>
<?php
}
?>
</body>
</html>