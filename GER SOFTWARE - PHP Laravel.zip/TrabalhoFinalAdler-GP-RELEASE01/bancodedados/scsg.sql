-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 08. Nov 2018 um 02:03
-- Server-Version: 10.1.34-MariaDB
-- PHP-Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `scsg`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cliente`
--

CREATE TABLE `cliente` (
  `username` varchar(50) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `endereco` varchar(50) NOT NULL,
  `telefone` int(11) NOT NULL,
  `cpf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cliente`
--

INSERT INTO `cliente` (`username`, `nome`, `email`, `endereco`, `telefone`, `cpf`) VALUES
('rarysh', 'rarysh', 'rarysh.costa@gmail.com', 'Rua Isaura Lemos Machado, 109,morro Chic', 36227224, 2147483647);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `login`
--

INSERT INTO `login` (`username`, `password`, `tipo`) VALUES
('daciololo', '123', 0),
('rarysh', '123', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `profissional`
--

CREATE TABLE `profissional` (
  `username` varchar(20) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `endereco` varchar(50) NOT NULL,
  `telefone` int(11) NOT NULL,
  `cnpj` int(11) DEFAULT NULL,
  `cpf` int(11) DEFAULT NULL,
  `especializacao` varchar(20) NOT NULL,
  `servicos` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `profissional`
--

INSERT INTO `profissional` (`username`, `nome`, `email`, `endereco`, `telefone`, `cnpj`, `cpf`, `especializacao`, `servicos`) VALUES
('daciololo', 'Daciololo', 'daciololo@gloria.deu', 'Monte', 123, 123, 123, 'Religiao', 'Gloria a Deus'),
('dilma', 'Dilma', 'dilma@ipsum.deu', 'Casa', 123, 123, 123, 'Falar merda', 'Servicos');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `requisicao`
--

CREATE TABLE `requisicao` (
  `req_id` int(11) NOT NULL,
  `req_data` date NOT NULL,
  `req_tipo_servico` varchar(20) NOT NULL,
  `req_forma_pagamento` varchar(20) NOT NULL,
  `req_cliente` varchar(20) NOT NULL,
  `profissional` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `requisicao`
--

INSERT INTO `requisicao` (`req_id`, `req_data`, `req_tipo_servico`, `req_forma_pagamento`, `req_cliente`, `profissional`) VALUES
(18, '2007-11-18', 'Transportadora', 'Boleto', 'rarysh', '');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`username`);

--
-- Indizes für die Tabelle `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indizes für die Tabelle `profissional`
--
ALTER TABLE `profissional`
  ADD PRIMARY KEY (`username`);

--
-- Indizes für die Tabelle `requisicao`
--
ALTER TABLE `requisicao`
  ADD PRIMARY KEY (`req_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `requisicao`
--
ALTER TABLE `requisicao`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
