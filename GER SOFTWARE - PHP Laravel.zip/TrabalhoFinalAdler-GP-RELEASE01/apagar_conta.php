
<?php
include_once("validar.php");
// Pegar os campos do formulario



// Montar o SQL para pesquisar
if ($_SESSION['tipo']==0){
    $db = mysqli_connect("localhost", "root", "", "scsg");
    $sql1 = "DELETE FROM cliente 
          where username= '" . $login . "'";
    $res1 = mysqli_query($db, $sql1);
}else if ($_SESSION['tipo']==1){
    $db = mysqli_connect("localhost", "root", "", "scsg");
    $sql1 = "DELETE FROM profissional 
          where username= '" . $login . "'";
    $res1 = mysqli_query($db, $sql1);
}



$sql2 = "DELETE FROM login
          where username= '" . $login . "'";
$res = mysqli_query($db, $sql2);
header("Location:index.php?sucesso=Conta apagada com sucesso.");



unset($_SESSION['login']);
session_destroy();
?>