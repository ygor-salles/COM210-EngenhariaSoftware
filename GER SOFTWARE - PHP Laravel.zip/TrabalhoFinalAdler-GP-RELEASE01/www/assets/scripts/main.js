var page = '';
var usuario= new Array();
var filtros = {
    nomeArg: '',
    estadoArg: '',
    cidadeArg: '',
    sexoArg: '',
    temaArg: '',
    p:'S',
};

var perfil='';

var _psicologos=new Array();
var _psicologo=new Array();
var _pesquisar_psicologos="";
var _numero_da_pagina=1;
var _numero_por_pagina=10;
var _ultimo_posicao=0;


var _link_consulta="";
var _agendar_consulta=new Array();



document.addEventListener('init', function (event) {
    iniciar_componentes();
    page = event.target;

    if (page.id === 'conta') {
        iniciar_conta();
    }else if(page.id === 'lista_psicologos'){
        _numero_da_pagina=1;

        iniciar_lista_psicologos();
        $("#lista_de_psicologos_final").hide();
        $("#loading_psicologos").hide();
        page.onInfiniteScroll = function (done) {
            done();
            $("#loading_psicologos").show();
            _numero_da_pagina++;
            carregar_psicologos();
        };
    }else if(page.id === 'psicologo'){
        iniciar_psicologo();
    }else if(page.id === 'agendar_consulta'){
        iniciar_agendar_consulta();
    }

});

function onLoad() {
    document.addEventListener("deviceready", onDeviceReady, false);
    document.addEventListener('deviceready', startImageCache, false);
    window.open = cordova.InAppBrowser.open;
    usuario=get_sessao_usuario();

    $.ajax({
        url: get_avatar_paciente(usuario['id_paciente']),
        success: function (data) {
            $("#usuario_avatar").attr("src",get_avatar_paciente(usuario['id_paciente']));
        },
        error: function (data) {
            $("#usuario_avatar").attr("src","assets/images/avatar.png");
        }
    });
   //set_perfil("https://www.psicologiaviva.com.br/psicologofp");
}
function onDeviceReady() {
    document.addEventListener("pause", onPause, false);
    document.addEventListener("resume", onResume, false);




}
function onPause() {
}
function onResume() {

}








function pesquisar_filtros(){
    filtros['nomeArg']=$("#nomeArg").val();
    filtros['estadoArg']=$("#estadoArg").val();
    filtros['cidadeArg']=$("#cidadeArg").val();
    filtros['sexoArg']=$("#sexoArg").val();
    filtros['temaArg']=$("#temaArg").val();
    _pesquisar_psicologos = webservice_pesquisar_completo;
    navegacao.pushPage('lista_psicologos.html');
}
function iniciar_lista_psicologos() {
    carregando("");
        console.log(filtros);
        var conexao = checkConnection();
        if (conexao['resposta'] != 'unknown' && conexao['resposta'] != 'none') {
            $.ajax({
                async: true,
                crossDomain: true,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin":"*"
                },
                method: "GET",
                dataType: 'json',
                url: _pesquisar_psicologos,
                data: filtros,
                success: function (data) {
                    if (data['error']) {
                        finalizado();
                        alert(data['error_msg'], '', 'Continuar', '');
                    } else {
                        _psicologos = data[0]['lista'];
                        var count = _psicologos.length;
                        _ultimo_posicao=0;
                        if (count > 0) {
                            carregar_psicologos();
                            }else{
                            $("#lista_de_psicologos").append(' <ons-card class="card_psicologo" style="text-align: center">Nenhum resultado encontrato</ons-card>');
                            }
                        $("#div_lista_de_psicologos").show();
                        finalizado();
                    }
                },
                error: function () {
                    finalizado();
                    alert('Não foi possível executar essa ação no momento', '', 'Continuar', '');
                }
            });
        } else {
            noConnection();
        }

}
function carregar_psicologos(){
    console.log("entrou_posicao"+_ultimo_posicao);
    console.log("pagina"+(_numero_por_pagina*_numero_da_pagina));
    var html = '';
    var count=0;
    if((_numero_por_pagina*_numero_da_pagina)>=_psicologos.length){
        count=_psicologos.length;
        $("#loading_psicologos").hide();
        $("#lista_de_psicologos_final").show();
        console.log("entrou aqui");
    }else{
        count =_numero_por_pagina*_numero_da_pagina;
    }
    console.log(count);
    console.log("ultima"+_ultimo_posicao);
    if(_ultimo_posicao<(count-1)){
        for (var i = _ultimo_posicao; i < count; i++) {
            _ultimo_posicao=i;
            console.log('posicao'+i);
            var psicologo = _psicologos[_ultimo_posicao];
            monta_layout_psicologo(psicologo,_ultimo_posicao);
        }
    }


}
function monta_layout_psicologo(psicologo,posicao){
    html = `
                            <ons-card class="card_psicologo">                            
                             <div class="card_psicologo_imagem_div"><div class="imagem_thumb"><figure><img id="card_psicologo_`+posicao+`" src="" /></figure></div></div>
                             <div class="card_psicologo_nome">` + psicologo['nome'] + `</div> 
                             <div class="card_psicologo_stars">
                             <img class="card_psicologo_star" src="assets/images/star.svg" alt="Ícone de estrela">
                             <img class="card_psicologo_star" src="assets/images/star.svg" alt="Ícone de estrela">
                             <img class="card_psicologo_star" src="assets/images/star.svg" alt="Ícone de estrela">
                             <img class="card_psicologo_star" src="assets/images/star.svg" alt="Ícone de estrela">
                             <img class="card_psicologo_star" src="assets/images/star.svg" alt="Ícone de estrela">                            
                             
                             </div>
                             <div class="card_psicologo_crp">` + psicologo['crp'] + `</div>
                             <div class="divider card_psicologo_divider"></div>                            
                             <div class="card_psicologo_descricao">` + psicologo['descricao'] + `</div>
                             <div class="divider card_psicologo_divider"></div>
                             
                              <div class="card_psicologo_div_titulo">
                              <span class="card_psicologo_titulo">Título</span>
                              <div  class="card_psicologo_titulo_tag">
                              <span class="tag">` + psicologo['titulo'] + `</span>
                              </div>
                              </div>
                             
                              <span class="card_psicologo_sessao">Sessão</span>
                              <div class="card_psicologo_sessao_info"><img src="assets/images/tag-money.svg" alt=""> <span> R$ ` + psicologo['valor'].replace('.',',') + `</span></div>
                              <div class="card_psicologo_sessao_info"><img src="assets/images/tag-clock.svg" alt=""> <span> ` + psicologo['tempo'] + ` min</span></div>
                              <div class="divider card_psicologo_divider"></div>
                               <div class="card_psicologo_button">  <ons-button onclick="set_perfil('` + psicologo['perfil'] + `')" class="button-default button-default-blue" modifier="large">MARQUE UMA CONSULTA</ons-button></div>
                             </ons-card>`;
    $("#lista_de_psicologos").append(html);
    imagem_sessao(psicologo['foto'],posicao);
}


function iniciar_psicologo(){
    carregando("");
    var data = {
        login: perfil
    };
    var conexao = checkConnection();
    if (conexao['resposta'] != 'unknown' && conexao['resposta'] != 'none') {

        $.ajax({
            async: true,
            crossDomain: true,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin":"*"
            },
            method: "GET",
            dataType: 'json',
            url: webservice_perfil,
            data: data,
            success: function (data) {
                if (data['error']) {
                    finalizado();
                    alert(data['error_msg'], '', 'Continuar', '');
                } else {
                    _psicologo=data[0];
                    $("#psicologo_imagem").attr("src",get_avatar_profissional(_psicologo['id']));
                    var target = $("#psicologo_imagem");
                    ImgCache.isCached(target.attr('src'), function(path, success) {
                        if (success) {
                            // already cached
                            ImgCache.useCachedFile(target);
                        } else {
                            // not there, need to cache the image
                            ImgCache.cacheFile(target.attr('src'), function () {
                                ImgCache.useCachedFile(target);
                            });
                        }
                    });

                    $("#psicologo_nome").html(_psicologo['nome']);
                    $("#psicologo_valor").html("R$ "+_psicologo['valorConsulta']);
                    $("#psicologo_tempo").html('Tempo de consulta: '+_psicologo['tempoConsulta']+' Minutos');
                    $("#psicologo_crp").html(_psicologo['titulo']+' '+_psicologo['crp']+' / '+_psicologo['estadoCRP']);
                    $("#psicologo_estado_cidade").html(_psicologo['cidade']+'/'+_psicologo['estado']);

                    $("#psicologo_descricao").html(_psicologo['descricao']);
                    $("#psicologo_formacao").html(_psicologo['formacao']);

                    $("#psicologo_valor_online").html("R$ "+_psicologo['valorConsulta']);
                    $("#psicologo_valor_online_presencial").html("R$ "+_psicologo['valorConsultaPresencial']);

                    temas = _psicologo['temas'][0];
                    carregar_temas(temas);

                    if(_psicologo['enderecoPerfil']=="S"){
                        $("#perfil_psicologo_localizacao").html('<iframe id="frameEndereco" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" width="100%" height="450" src="https://maps.google.com/maps?hl=pt&q='+_psicologo['endereco']+','+_psicologo['numero']+','+_psicologo['bairro']+', '+_psicologo['cidade']+'&ie=UTF8&t=m&z=17&iwloc=B&output=embed"></iframe>');

                    }else{
                        $("#perfil_psicologo_localizacao").html('');
                    }

                    atualizar_componentes();

                    $('.open-presencial').click(function (e) {
                        e.preventDefault();
                        $('.calendario-online').fadeOut(0);
                        $('.calendario-presencial').fadeIn(0);
                        $('.open-online').removeClass('ativo');
                        $('.open-presencial').addClass('ativo');
                        $('#valor-online').hide();
                        $('#valor-presencial').show();
                        $('.eventsCalendar-subtitle').text('DISPONIBILIDADE PRESENCIAL');
                        ajustaTamanho();
                    });
                    $('.open-online').click(function (e) {
                        e.preventDefault();
                        $('.calendario-online').fadeIn(0);
                        $('.calendario-presencial').fadeOut(0);
                        $('.open-presencial').removeClass('ativo');
                        $('.open-online').addClass('ativo');
                        $('#valor-online').show();
                        $('#valor-presencial').hide();
                        $('.eventsCalendar-subtitle').text('DISPONIBILIDADE ONLINE');
                       ajustaTamanho();
                    });

                     finalizado();
                }
            },
            error: function () {
                finalizado();
                alert('Não foi possível executar essa ação no momento', '', 'Continuar', '');
            }
        });
    } else {
        noConnection();
    }
}
function filtro_imagem(id){
    console.log("entrou");
    $(".filtro_temas").hide();
    $("#div_lista_de_psicologos").hide();
    $("#div_filtros").show();
    switch (id) {
     case 1:
            $("#div_filtro_familia").show();
            break;
        case 2:
            $("#div_filtro_criancas").show();
            break;

        case 3:
            $("#div_filtro_relacionamento_afetivo").show();
            break;

        case 4:
            $("#div_filtro_questoes_profissionais").show();
            break;
        case 5:
            $("#div_filtro_doencas_graves").show();
            break;

        case 6:
            $("#div_filtro_auto_conhecimento").show();
        break;
    }
    if(id==0){
        $("#div_filtro_temas").hide();
        $("#div_filtro_imagens").show();

    }else{
        $("#div_filtro_temas").show();
        $("#div_filtro_imagens").hide();

    }
}
function iniciar_conta(){
    console.log(usuario);
    $("#conta_imagem").attr("src",get_avatar_paciente(usuario['id_paciente']));
    $("#conta_nome_paciente").val(usuario['nome_paciente']);
    $("#conta_email_paciente").val(usuario['email_paciente']);
    $("#conta_telefone_paciente").val(usuario['telefone_paciente']);
    $("#conta_cpf_paciente").val(usuario['cpf_paciente']);
    $("#conta_dataNascimento_paciente").val(usuario['dataNascimento_paciente']);
    $("#conta_convenio_paciente").val(usuario['convenio_paciente']);
    $("#conta_sexo_paciente").val(usuario['sexo_paciente']);


}


function agendar_consulta(url){
    _link_consulta=url;
    _agendar_consulta['dataConsulta']=queryString("dataConsulta",url);
    _agendar_consulta['loginProfissional']=queryString("loginProfissional",url);
    _agendar_consulta['loginFinaliza']=queryString("loginFinaliza",url);
    _agendar_consulta['AA']=queryString("AA",url);
    console.log(_agendar_consulta);
    navegacao.pushPage('agendar_consulta.html');
}


function iniciar_agendar_consulta(){
$("#agendar-consulta-psicologo-nome").html(_psicologo['nome']);
$("#agendar-consulta-info-crp ").html(_psicologo['titulo']+' '+_psicologo['crp']+' / '+_psicologo['estadoCRP']);

$("#agendar-consulta-info-regiao").html(_psicologo['cidade']+'/'+_psicologo['estado']);

    $("#agendar-consulta-conteudo-data").html(_agendar_consulta['dataConsulta'].substring(8, 10)+"/"+_agendar_consulta['dataConsulta'].substring(5,7)+"/"+_agendar_consulta['dataConsulta'].substring(0, 4));
    $("#agendar-consulta-conteudo-horario").html(_agendar_consulta['dataConsulta'].substring(11, 16));

    $("#agendar-consulta-conteudo-tempo").html(_psicologo['tempoConsulta']);
    if( _agendar_consulta['AA']=="ONLINE"){
        $("#agendar-consulta-text-valor").html("R$ "+_psicologo['valorConsulta'].toFixed(2).replace(".",","));
    }else{
        $("#agendar-consulta-text-valor").html("R$ "+_psicologo['valorConsultaPresencial'].toFixed(2).replace(".",","));
    }

    $("#agendar-consulta-imagem").attr("src",get_avatar_profissional(_psicologo['id']));
    var target = $("#agendar-consulta-imagem");
    ImgCache.isCached(target.attr('src'), function(path, success) {
        if (success) {
            // already cached
            ImgCache.useCachedFile(target);
        } else {
            // not there, need to cache the image
            ImgCache.cacheFile(target.attr('src'), function () {
                ImgCache.useCachedFile(target);
            });
        }
    });


}
