﻿ons.platform.select('android');
var dominio = 'https://www.psicologiaviva.com.br/';
var webservice_login = dominio+'consultorioonline/soa/loginpac';
var webservice_recuperar_senha = dominio+'consultorioonline/soa/senha';
var webservice_registrar = dominio+'consultorioonline/soa/apppaciente';
var webservice_pesquisar = dominio+'consultorioonline/soa/buscapsicologobreve';
var webservice_perfil = dominio+'consultorioonline/soa/perfil';
var webservice_pesquisar_completo = dominio+'consultorioonline/soa/buscapsicologocatalogo';
var webservice_agenda_online= dominio+'consultorioonline/soa/agendas?login=';
var webservice_agenda_presencial= dominio+'consultorioonline/soa/agendaspresencial?login=';
window.fn = {};

window.fn.open = function () {
    var menu = document.getElementById('menu');
    menu.open();
};

window.fn.load = function (page) {
    var content = document.getElementById('content');
    var menu = document.getElementById('menu');
    content.load(page)
        .then(menu.close.bind(menu));
    var navegacao = document.getElementById('navegacao');


};

function menuLink(page) {
    var content = document.getElementById('content');
    var menu = document.getElementById('menu');
    content.load(page)
        .then(menu.close.bind(menu));
   
}

function trocar_de_pagina(page) {
    document.querySelector('#content').pushPage(page);
}

function set_sessao_usuario(data) {

    localStorage.setItem("id_paciente", data['id_paciente']);
    localStorage.setItem("convenio_paciente", data['convenio_paciente']);
    localStorage.setItem("dataNascimento_paciente", data['dataNascimento_paciente']);
    localStorage.setItem("email_paciente", data['email_paciente']);
    localStorage.setItem("estado_paciente", data['estado_paciente']);
    localStorage.setItem("idFoto_paciente", data['idFoto_paciente']);
    localStorage.setItem("nome_paciente", data['nome_paciente']);
    localStorage.setItem("sexo_paciente", data['sexo_paciente']);
    localStorage.setItem("telefone_paciente", data['telefone_paciente']);
    localStorage.setItem("logado", true);
  
}

function get_sessao_usuario() {
 
    var data = {
        id_paciente: localStorage.getItem("id_paciente"),
        convenio_paciente: localStorage.getItem("convenio_paciente"),
        cpf_paciente: localStorage.getItem("cpf_paciente"),
        dataNascimento_paciente: localStorage.getItem("dataNascimento_paciente"),
        email_paciente: localStorage.getItem("email_paciente"),
        estado_paciente: localStorage.getItem("estado_paciente"),
        idFoto_paciente: localStorage.getItem("idFoto_paciente"),
        nome_paciente: localStorage.getItem("nome_paciente"),
        sexo_paciente: localStorage.getItem("sexo_paciente"),
        telefone_paciente: localStorage.getItem("telefone_paciente"),
        logado: localStorage.getItem("logado"),
    };
    return data;
}

function logout_sessao() {
    localStorage.setItem("id_paciente", '');
    localStorage.setItem("convenio_paciente", '');
    localStorage.setItem("cpf_paciente", '');
    localStorage.setItem("dataNascimento_paciente", '');
    localStorage.setItem("email_paciente", '');
    localStorage.setItem("estado_paciente", '');
    localStorage.setItem("idFoto_paciente", '');
    localStorage.setItem("nome_paciente", '');
    localStorage.setItem("sexo_paciente", '');
    localStorage.setItem("telefone_paciente", '');
    localStorage.setItem("logado", '');
    location.href='autenticacao.html';
}

function carregando(msg) {
    if (msg == undefined) {
        msg = '';
    }
    $(".conteiner").hide();
    $(".conteiner-info").html('<div style="text-align: center;" class="loading">' +
        '<div style= "margin-top:50%;"></div>' +
        '<p><ons-progress-circular indeterminate style="font-size: 30px;"></ons-progress-circular></p>' +
        '<p id="loading-label">' + msg+'</p>' +
        '</div>');
    $(".conteiner-info").show();
}

function finalizado() {
    $(".conteiner").show();
    $(".conteiner-info").hide();
    $(".conteiner-info").html('');
}

function sem_conexao() {

    $(".conteiner").hide();
    $(".conteiner-info").html('<div class="no-connection" style="text-align:center" id="sem-conexao" onclick="pageLink(\'' + id + '.html\')" >' +
        '<p><img src="assets/images/no-connection.png" ></p>' +
        '<p><h3 style="color: #454f57; background-color: #cdcece; padding-top: 10px; margin-bottom: -30px;">Sem Conexão</h3></p>'+
        '</br><p><h5 style="color: #454f57; background-color: #dbdddd; padding-bottom: 10px;">Clique para Recarregar</h5></p>'+
        '</div>');
    $(".conteiner-info").show();

        
}

function validar_permissoes() {
    var per = false;
    switch (device.platform) {
        case "Android":
            per = true;
            break;
        case "iOS":

            break;
    }


if (per) {
    var permissions = cordova.plugins.permissions;
    permissions.checkPermission(permissions.CAMERA, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.CAMERA,
                function (status) { },
                function () {
                    console.warn('Camera permission is not turned on');
                });
        }
    });


    permissions.checkPermission(permissions.WRITE_EXTERNAL_STORAGE, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.WRITE_EXTERNAL_STORAGE,
                function (status) { },
                function () {
                    console.warn(' permission is not turned on');
                });
        }
    });


    permissions.checkPermission(permissions.INTERNET, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.INTERNET,
                function (status) { },
                function () {
                    console.warn(' permission is not turned on');
                });
        }
    });

    permissions.checkPermission(permissions.ACCESS_NETWORK_STATE, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.ACCESS_NETWORK_STATE,
                function (status) { },
                function () {
                    console.warn(' permission is not turned on');
                });
        }
    });

    permissions.checkPermission(permissions.WAKE_LOCK, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.WAKE_LOCK,
                function (status) { },
                function () {
                    console.warn(' permission is not turned on');
                });
        }
    });

    permissions.checkPermission(permissions.VIBRATE, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.VIBRATE,
                function (status) { },
                function () {
                    console.warn(' permission is not turned on');
                });
        }
    });

    permissions.checkPermission(permissions.RECEIVE_BOOT_COMPLETED, function (status) {
        if (status.hasPermission) {
            // console.log("Yes :D ");
        }
        else {
            permissions.requestPermission(permissions.RECEIVE_BOOT_COMPLETED,
                function (status) { },
                function () {
                    console.warn(' permission is not turned on');
                });
        }
    });

}

}

































