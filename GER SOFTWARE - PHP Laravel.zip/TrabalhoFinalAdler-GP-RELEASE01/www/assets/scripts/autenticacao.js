﻿var page = '';
var _usuario;


document.addEventListener('init', function (event) {
    page = event.target;
    iniciar_componentes_login();
    if (page.id === 'login') {
    }else  if (page.id === 'registrar') {
    }else  if (page.id === 'recuperar_senha') {
    }
});

function onLoad() {
    document.addEventListener("deviceready", onDeviceReady, false);

}
function onDeviceReady() {
    document.addEventListener("pause", onPause, false);
    document.addEventListener("resume", onResume, false);
    window.open = cordova.InAppBrowser.open;
    _usuario =get_sessao_usuario();
    console.log(_usuario['logado']+"entrou");
    if(_usuario['logado']){
        location.href="main.html";
    }
}
function onPause() {
}
function onResume() {

}


/***
*
*Registrar
*
****/

var flag_convenio=false;
function registrar_abrir_campo_convenio(){
    if(!flag_convenio){
        $("#registrar_convenio").show();
          flag_convenio=true;
    }else{
        $("#registrar_convenio").hide();
        flag_convenio=false;
          
    }
}



function login() {
    carregando("Autenticando");
    var data = {
        email: $("#email").val(),
        senha: $("#senha").val()
    };
    console.log(data);
    var flag = true;
    if (data['email'] == "" || data['senha'] == "") {
        flag = false;
        alert('Por favor insira o seu e-mail e senha ', '', 'Continuar', '');
        finalizado();
    }
    if (flag) {
        var conexao = checkConnection();
        if (conexao['resposta'] != 'unknown' && conexao['resposta'] != 'none') {
            $.ajax({
                async: true,
                crossDomain: true,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin":"*"
                },
                method: "POST",
                dataType: 'json',
                url: webservice_login,
                data: JSON.stringify(data),
                success: function (data) {
                    console.log(data['id_paciente']);
                    console.log(data['ERRO']);
                    console.log(data['error']+"--");
                    if (data['id_paciente']=='undefined' || data['id_paciente']==undefined) {
                        finalizado();
                        alert(data['ERRO'], '', 'Continuar', '');
                    } else {
                       set_sessao_usuario(data);
                      location.href="main.html";
                    }
                },
                error: function () {
                    finalizado();
                    alert('N&atilde;o foi poss&iacute;vel efetuar o login neste momento.', '', 'Continuar', '');
                }
            });
        } else {
            sem_conexao();
        }
    }

}





function recuperar_senha() {
    carregando("");

    var data = {
        error: '',
        login: $("#recuperar_senha_email").val()
    };
    console.log(data);
    var flag = true;
    if (data['email'] == "") {
        flag = false;
        alert('Por favor insira o seu e-mail', '', 'Continuar', '');
        finalizado();
    }
    if (flag) {
        var conexao = checkConnection();
        if (conexao['resposta'] != 'unknown' && conexao['resposta'] != 'none') {
            $.ajax({
                async: true,
                crossDomain: true,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin":"*"
                },
                method: "GET",
                dataType: 'json',
                url: webservice_recuperar_senha,
                data: data,
                success: function (data) {
                    if (data['error']) {
                        finalizado();
                        alert(data['error_msg'], '', 'Continuar', '');
                    } else {
                        finalizado();
                        $("#recuperar_senha_div").hide();
                        $("#recuperar_senha_div_sucesso").show();
                    }
                },
                error: function () {
                    finalizado();
                    alert('N&atilde;o foi poss&iacute;vel efetuar o login neste momento.', '', 'Continuar', '');
                }
            });
        } else {
            sem_conexao();
        }
    }

}






function registrar() {
    carregando("CADASTRANDO");
    var data = {
        error: '',
        nome: $("#registrar_nome").val(),
        email: $("#registrar_email").val(),
        senha: $("#registrar_senha").val(),
        telefone: $("#registrar_telefone").val(),
        termo: document.querySelector("#termo").checked
    };
    var flag = true;
    if (data['nome'] == "" || data['email'] == "" || data['senha'] == "" || data['telefone'] == "") {
        flag = false;
        alert('Preencha todos os campos obrigatórios!', '', 'Continuar', '');
        finalizado();
    }

    if (data["termo"]===false) {
        flag = false;
        alert('Aceite o termo de privacidade para continuar!', '', 'Continuar', '');
        finalizado();
    }
    console.log(data);
    if (flag) {
        var conexao = checkConnection();
        if (conexao['resposta'] != 'unknown' && conexao['resposta'] != 'none') {
            $.ajax({
                async: true,
                crossDomain: true,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin":"*"
                },
                method: "POST",
                dataType: 'json',
                url: webservice_registrar,
                data: JSON.stringify(data),
                success: function (data) {
                    if (data['error']) {
                        finalizado();
                        alert(data['error_msg'], '', 'Continuar', '');
                    } else {
                        trocar_de_pagina("cadastro_com_sucesso.html");
                    }
                },
                error: function () {
                    finalizado();
                    alert('N&atilde;o foi poss&iacute;vel efetuar o login neste momento.', '', 'Continuar', '');
                }
            });
        } else {
            sem_conexao();
        }
    }

}































