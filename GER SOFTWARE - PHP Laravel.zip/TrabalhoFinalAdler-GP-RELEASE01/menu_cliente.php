<?php include "view/header.php"; ?>

<ons-page id="home_nav">
    <div class="container_cli">
        <div class="left">
            <a href="home_cliente.php"><ons-back-button ></ons-back-button></a>
            <img width="71px" height="34px" src="www/assets/images/logo_roxo.png" style="margin-left: 110px; margin-top: 5px">
        </div>
        <ons-list>
            <ons-list-item>
                <a class="central" href="buscar_profissional.php"><div class="centralizar nav-text-color">Buscar Profissional</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="alterar_cliente.php"><div class="centralizar nav-text-color">Alterar Dados</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="#"><div class="centralizar nav-text-color">Ver Requisições</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="#"><div class="centralizar nav-text-color">Rastrear Pedidos</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="#"><div class="centralizar nav-text-color">Histórico de Pedidos</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="confirmar_apagar.php"><div class="centralizar nav-text-color">Apagar Conta</div></a>
            </ons-list-item>
            <ons-list-item></ons-list-item>
        </ons-list>
        <div class="form-group">
            <div class="form-input">
                <button onclick="window.location.href='logout.php'" class="button-default login-button-default"
                            modifier="medium">Logout
                </button>
            </div>
        </div>
    </div>
</ons-page>

</body>
</html>