<?php include "view/header.php";
$login = $_SESSION["login"];
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql = "SELECT * from profissional JOIN login ON profissional.username = login.username where profissional.username='" . $login . "'";
$result = $db->query($sql);
while ($row = $result->fetch_assoc()){
?>
<ons-page id="registrar">
    <div class="container_cli">
        <div class="left">
            <a href="menu_profissional.php"><ons-back-button ></ons-back-button></a>
        </div>
        <div class="centralizar">
            <img width="105px" height="97px" src="www/assets/images/autonomo.png">
        </div>
        <p class="centralizar" style="padding: 30px 0;">
            Preencha todos os campos abaixos
        </p>
        <form action="alterar_profissional_be.php" method="post" name="Cadastroprofissional">
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["username"]; ?>" name="registrar_nome" class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Nome">
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["email"]; ?>" name="registrar_email"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="email" placeholder="Email" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["endereco"]; ?>" name="registrar_endereco"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Endereço" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["telefone"]; ?>" name="registrar_telefone"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Telefone" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["cpf"]; ?>" disabled name="registrar_cpf"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="CPF" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["cnpj"]; ?>" disabled name="registrar_cnpj"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="CNPJ" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["especializacao"]; ?>" disabled name="registrar_especializacao"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Especialização" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["servicos"]; ?>" disabled name="registrar_servicos"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Serviços" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input disabled value="<?php echo $row["username"]; ?>" name="registrar_username"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="text" placeholder="Nome de usuário" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["password"]; ?>" name="registrar_senha"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="password" placeholder="Senha" >
                </p>
            </div>
            <div class="form-group">
                <p>
                    <input value="<?php echo $row["password"]; ?>" name="registrar_senha2"  class="registrar-input text-input text-input--material text-input--underbar" modifier="underbar" type="password" placeholder="Repetir senha" >
                </p>
            </div>

            <div class="form-group">
                <div class="form-input" style="margin-top:50px;">
                    <button type="submit" class="button-default login-button-default"
                                modifier="medium">Continuar
                    </button>
                </div>
            </div>
        </form>
    </div>
</ons-page>

<?php

}
?>
</body>
</html>