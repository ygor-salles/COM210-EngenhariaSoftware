<?php

// Pegar os campos do formulario
$radio = $_POST["registrar_tipo"];
//
// Montar o SQL para pesquisar
if($radio=="cliente"){
    header("Location:registrar_cliente.php");
} else if ($radio =="profissional"){
    // Login e senha NAO conferem
    header("Location:registrar_profissional.php");
}else{
    header("Location:registrar.php");
}
?>