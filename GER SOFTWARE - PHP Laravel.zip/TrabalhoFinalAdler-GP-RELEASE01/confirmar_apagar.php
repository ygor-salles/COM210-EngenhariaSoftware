<?php include "view/header.php"?>
<ons-page id="recuperar_senha">
    <div class="container_cli">
        <div class="left">
            <a href="home_cliente.php"><ons-back-button></ons-back-button></a>
        </div>
        <p class="centralizar" style="margin-bottom: 50px">
            Você realmente deseja apagar a conta?
        </p>
        <ons-row>
            <ons-col>
                <div class="form-group">
                    <div class="form-input">
                        <button onclick="window.location.href='home_cliente.php'" class="button-default login-button-default"
                                modifier="medium">Cancelar<?php echo $_SESSION['tipo']; ?>
                        </button>
                    </div>
                </div>
            </ons-col>
            <ons-col>
                <div class="form-group">
                    <div class="form-input">
                        <button onclick="window.location.href='apagar_conta.php'" class="button-default login-button-default"
                                modifier="medium">Apagar
                        </button>
                    </div>
                </div>
            </ons-col>
        </ons-row>
    </div>
</ons-page>

</body>
</html>