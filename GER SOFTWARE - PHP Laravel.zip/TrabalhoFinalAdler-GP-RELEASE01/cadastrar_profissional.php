<?php

// Pegar os campos do formulario
$nome = $_POST["registrar_nome"];
$email = $_POST["registrar_email"];
$endereco = $_POST["registrar_endereco"];
$telefone = $_POST["registrar_telefone"];
$cpf = $_POST["registrar_cpf"];
$username = $_POST["registrar_username"];
$senha = $_POST["registrar_senha"];
$senhaagain = $_POST["registrar_senha2"];

$servicos = $_POST["registrar_servicos"];
$especializacao = $_POST["registrar_especializacao"];
$cnpj = $_POST["registrar_cnpj"];

if( $senha!=$senhaagain){
    header("Location:registrar_cliente.php?erro=Senhas diferentes");
}


// Montar o SQL para pesquisar
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql1 = "INSERT into profissional (nome, email, endereco, telefone, cpf, username, cnpj, servicos, especializacao) values (" . "'" . $nome . "','" .  $email . "','" . $endereco . "','" .  $telefone . "','" .  $cpf . "','" .  $username . "','" . $cnpj  . "','" . $servicos . "','" . $especializacao . "'" . ")";
$res1 = mysqli_query($db, $sql1);

$sql2 = "INSERT into login (username, password) values (" . "'" . $username . "','" . $senha . "','" . 0 . "'" . ")";
$res = mysqli_query($db, $sql2);

header("Location:index.php?sucesso=Cadastrado com sucesso");
?>