<?php include "view/header.php";
$login = $_SESSION["login"];
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql = "SELECT * from profissional JOIN login ON profissional.username = login.username where profissional.username='" . $login . "'";
$result = $db->query($sql);
while ($row = $result->fetch_assoc()){
?>
<ons-page id="home">
    <div class="container_prof">
        <div class="central">
            <img width="71px" height="34px" src="www/assets/images/logo_roxo.png">
        </div>
        <div class="home-header">
            <div class="page home-head">
                <div class="home-img">
                    <img class="profile-image" src="www/assets/images/profile-generic.jpg" width="65px" height="65px" style="border-radius:50%;"/>
                </div>
                <div class="home-txt">
                    <div class="home_title text-center">
                        <?php echo $row['nome'];?>
                    </div>
                    <div class="home_conteudo_card_principal">
                        <div class="home-conteudo text-center" style="color:#818181; font-size:11px; padding: 5px 0">
                            <ons-icon icon="md-pin" class="home_pin_icon"></ons-icon>
                            <?php echo $row['endereco'];?>
                        </div>
                        <div class="home_stars text-center">
                            <img class="perfil_psicologo_star" src="www/assets/images/star.svg" alt="Ícone de estrela">
                            <img class="perfil_psicologo_star" src="www/assets/images/star.svg" alt="Ícone de estrela">
                            <img class="perfil_psicologo_star" src="www/assets/images/star.svg" alt="Ícone de estrela">
                            <img class="perfil_psicologo_star" src="www/assets/images/star.svg" alt="Ícone de estrela">
                            <img class="perfil_psicologo_star" src="www/assets/images/star-disabled.png" alt="Ícone de estrela">
                        </div>
                    </div>
                </div>
                <?php
                        if (isset($_GET["sucesso"])) {
                    $erro = $_GET["sucesso"];
                    echo "<CENTER><FONT color='#228b22'> $erro</FONT></CENTER>";
                }
        ?>
            </div>
        </div>
        <div class="content" style="margin-top: 100px;">
            <a href="alterar_cliente.php" style="font-style:none; color:#992e8c;">
                <div class="card agenda" style="background-color: #9a498c30!important;min-height: 70px;">
                    Alterar Dados
                </div>
            </a>
            <a href="#" style="font-style:none; color:#992e8c;">
                <div class="card arquivados" style="background-color: #9a498c30!important;min-height: 70px;">
                    Ver Requisições
                </div>
            </a>
            <a href="#" style="font-style:none; color:#992e8c;">
                <div class="card profissionais" style="background-color: #9a498c30!important;min-height: 70px;">
                    Pagamentos
                </div>
            </a>
            <a href="#" style="font-style:none; color:#992e8c;">
                <div class="card promocoes" style="background-color: #9a498c30!important;min-height: 70px;">
                    Histórico de Serviços
                </div>
            </a>
        </div>
        <div class="navigation" style="margin-top:50px">
            <div class="home-menu">
                <a href="#" onclick="window.location.href='menu_profissional.php';">
                    <img width="70px" height="70px" src="www/assets/images/home-nav.png">
                </a>
            </div>
            <div class="home-botao">
                <a href="#" onclick="#">
                    <img width="80px" height="cadastrar_cliente.php80px" src="www/assets/images/main-button.png">
                </a>
            </div>
            <div class="home-notificacao">
                <a href="#" onclick="trocar_de_pagina('notification.html');">
                    <img class="notify-button" width="32px" height="36px" src="www/assets/images/notification-button.png">
                </a>
            </div>
        </div>
    </div>
</ons-page>
<?php } ?>
</body>
</html>