<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport"
          content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
    <link rel="stylesheet" href="www/libs/onsen/css/onsenui.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/onsenui-core.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/onsen-css-components.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/ionicons/css/ionicons.min.css">
    <script type="text/javascript" src="www/libs/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="www/libs/mask/jquery.mask.js"></script>
    <script type="text/javascript" src="www/libs/onsen/js/onsenui.min.js"></script>
    <link rel="stylesheet" href="www/libs/onsen/css/theme.css">
    <link rel="stylesheet" href="www/assets/css/custom.css">
    <link rel="stylesheet" href="www/assets/css/profissional.css">
    <link rel="stylesheet" href="www/assets/css/cliente.css">

    <script type="text/javascript" src="www/assets/scripts/platformOverrides.js"></script>
    <script type="text/javascript" src="www/assets/scripts/funcoes.js"></script>
    <script type="text/javascript" src="www/assets/scripts/custom.js"></script>
    <script src="www/assets/scripts/autenticacao.js"></script>
    
    
    <title>Sistema de Contratação de Transportadores Autônomos</title>

</head>
<body>
	<?php
	include_once("validar.php");
	?>
