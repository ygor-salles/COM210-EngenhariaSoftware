<?php

// Pegar os campos do formulario
$login = $_POST["username"];
$senha = $_POST["password"];

// Montar o SQL para pesquisar
$db = mysqli_connect("localhost", "root", "", "scsg");
$sql = "SELECT * FROM login WHERE username = '$login' AND password = '$senha' ";
$res = mysqli_query($db, $sql);

$result = $db->query($sql);
while ($row = $result->fetch_assoc()){
    if ($row['username'] == $login){
        $tipo=$row['tipo'];
    }
}
if ($registro = mysqli_fetch_assoc($res)) {
    // Criar a sessao. Login e senha conferem
	session_start();
	$_SESSION["login"] = $login;
	$_SESSION["tipo"] = $tipo;
	if($_SESSION["tipo"]==1){
        header("Location:home_cliente.php");
    }else{
	    header("Location:home_profissional.php");
    }
} else {
    // Login e senha NAO conferem
	header("Location:index.php?erro=Usuario e/ou senha incorretos");
}
?>
