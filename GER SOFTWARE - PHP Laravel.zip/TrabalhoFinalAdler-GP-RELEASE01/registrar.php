<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport"
          content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
    <link rel="stylesheet" href="www/libs/onsen/css/onsenui.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/onsenui-core.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/onsen-css-components.min.css">
    <link rel="stylesheet" href="www/libs/onsen/css/ionicons/css/ionicons.min.css">
    <script type="text/javascript" src="www/libs/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="www/libs/mask/jquery.mask.js"></script>
    <script type="text/javascript" src="www/libs/onsen/js/onsenui.min.js"></script>
    <link rel="stylesheet" href="www/libs/onsen/css/theme.css">
    <link rel="stylesheet" href="www/assets/css/custom.css">
    <link rel="stylesheet" href="www/assets/css/profissional.css">
    <link rel="stylesheet" href="www/assets/css/cliente.css">

    <script type="text/javascript" src="www/assets/scripts/platformOverrides.js"></script>
    <script type="text/javascript" src="www/assets/scripts/funcoes.js"></script>
    <script type="text/javascript" src="www/assets/scripts/custom.js"></script>
    <script src="www/assets/scripts/autenticacao.js"></script>
    <title>Sistema de Contratação de Transportadores Autônomos</title>

</head>
<body>
<ons-page id="registrar">
    <div class="container_cli">
        <div class="left">
            <a href="index.php"><ons-back-button></ons-back-button></a>
        </div>
        <div class="centralizar">
            <img width="108px" height="81px" src="www/assets/images/registrar.png">
        </div>
        <p class="centralizar" style="padding: 30px;">
            Selecione o tipo de conta a ser criada
        </p>

        <form method="post" action="registrar_be.php">
            <div class="registrar_radio_categoria" class="form-group registrar_radio">
                <div class="registrar_radio_item estabelecimento">
                    <img width="105px" height="97px" src="www/assets/images/autonomo.png">
                    <label for="registrar_estabelecimento" class="center" style="display:block;">
                        Cliente
                    </label>
                    <label class="left">
                        <ons-radio name="registrar_tipo" value="cliente" input-id="registrar_estabelecimento"></ons-radio>
                    </label>
                </div>
                <div class="registrar_radio_item autonomo">
                    <label for="registrar_autonomo" class="center">
                        <img width="113px" height="97px" src="www/assets/images/estabelecimento.png">
                        Profissional
                    </label>
                    <label class="left">
                        <ons-radio name="registrar_tipo" value="profissional" input-id="registrar_autonomo"></ons-radio>
                    </label>
                </div>
            </div>
            <div class="form-group">
                <div class="form-input" style="margin-top:50px;">
                    <button type="submit" name="submit" class="button-default login-button-default"
                                modifier="medium">Continuar
                    </button>
                </div>
            </div>
        </form>
    </div>
</ons-page>

</body>
</html>