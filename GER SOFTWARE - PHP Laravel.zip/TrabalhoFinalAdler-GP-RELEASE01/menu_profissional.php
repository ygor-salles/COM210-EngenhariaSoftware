<?php include "view/header.php"; ?>

<ons-page id="home_nav">
    <div class="container_cli">
        <div class="left">
            <a href="home_profissional.php"><ons-back-button ></ons-back-button></a>
            <img width="71px" height="34px" src="www/assets/images/logo_roxo.png" style="margin-left: 110px; margin-top: 5px">
        </div>
        <ons-list>
            <ons-list-item>
                <a class="central" href="buscar_cliente.php"><div class="centralizar nav-text-color">Buscar Cliente</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="alterar_profissional.php"><div class="centralizar nav-text-color">Alterar Dados</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="#"><div class="centralizar nav-text-color">Ver Requisições</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="#"><div class="centralizar nav-text-color">Pagamentos</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="#"><div class="centralizar nav-text-color">Histórico de Serviços</div></a>
            </ons-list-item>
            <ons-list-item>
                <a class="central" href="apagar_conta.php"><div class="centralizar nav-text-color">Apagar Conta</div></a>
            </ons-list-item>
            <ons-list-item></ons-list-item>
        </ons-list>
        <div class="form-group">
            <div class="form-input">
                <button onclick="window.location.href='logout.php'" class="button-default login-button-default"
                            modifier="medium">Logout
                </button>
            </div>
        </div>
    </div>
</ons-page>

</body>
</html>